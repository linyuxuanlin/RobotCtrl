package com.atom.clond.demo.common;

/**
 * 需要全局常驻的变量
 *
 * @author bohan.chen
 */
public class GlobalValue {

    /**
     * 机构id
     */
    public static int orgId;

}
